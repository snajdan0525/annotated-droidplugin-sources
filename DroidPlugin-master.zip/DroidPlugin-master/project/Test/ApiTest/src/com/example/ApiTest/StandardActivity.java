package com.example.ApiTest;

public class StandardActivity extends LaunchModeTestActivity {


}
