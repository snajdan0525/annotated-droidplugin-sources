package com.example.ApiTest;

public class SingleTopActivity  extends LaunchModeTestActivity {

    public static class SingleTopActivity1 extends SingleTopActivity{}

    public static class SingleTopActivity2 extends SingleTopActivity{}

    public static class SingleTopActivity3 extends SingleTopActivity{}

    public static class SingleTopActivity4 extends SingleTopActivity{}

    public static class SingleTopActivity5 extends SingleTopActivity{}


}
